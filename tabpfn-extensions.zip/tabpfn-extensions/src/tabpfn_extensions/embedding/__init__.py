"""Embedding module for tabpfn_extensions package."""

from .tabpfn_embedding import TabPFNEmbedding

__all__ = ["TabPFNEmbedding"]
