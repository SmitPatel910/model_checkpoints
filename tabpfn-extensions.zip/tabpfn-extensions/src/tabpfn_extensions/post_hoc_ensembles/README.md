# TabPFN PHE Example Code with Refactor

This is an example code of TabPFN with refactor.

* Please install hyperopt by `pip install hyperopt` (also make sure kidtransformer is installed)
* Make sure to download the models to `post_hoc_ensembles/hpo_models`
